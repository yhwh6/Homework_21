﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp
{
    public class AuthenticationService
    {
        private const string BaseUrl = "http://localhost:44365"; // AspNetCore base URL

        public async Task<bool> Login(string username, string password)
        {
            var loginModel = new { Username = username, Password = password };
            var json = JsonConvert.SerializeObject(loginModel);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            using (var client = new HttpClient())
            {
                var response = await client.PostAsync($"{BaseUrl}/Account/Login", content);
                return response.IsSuccessStatusCode;
            }
        }

        public async Task<List<Contact>> GetContacts(string authToken)
        {
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {authToken}");
                var response = await client.GetAsync($"{BaseUrl}/PhoneBook/Index");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    var contacts = JsonConvert.DeserializeObject<List<Contact>>(json);
                    return contacts;
                }
                return null;
            }
        }

        public class Contact
        {
            public int ID { get; set; }
            public string LastName { get; set; }
            public string FirstName { get; set; }
            public string MiddleName { get; set; }
            public string PhoneNumber { get; set; }
            public string Address { get; set; }
            public string Description { get; set; }
        }
    }
}

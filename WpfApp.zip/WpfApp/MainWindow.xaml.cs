﻿using Microsoft.AspNetCore.Authentication;
using System.Windows;

namespace WpfApp
{
    public partial class MainWindow : Window
    {
        private readonly AuthenticationService authService;

        public MainWindow()
        {
            InitializeComponent();
            authService = new AuthenticationService();
        }

        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            var username = UsernameTextBox.Text;
            var password = PasswordTextBox.Password;

            var loggedIn = await authService.Login(username, password);
            if (loggedIn)
            {
                var contacts = await authService.GetContacts("auth_token_here");
                if (contacts != null)
                {
                    ContactsListBox.ItemsSource = contacts;
                }
                else
                {
                    MessageBox.Show("Failed to get contacts.");
                }
            }
            else
            {
                MessageBox.Show("Login failed.");
            }
        }
    }
}